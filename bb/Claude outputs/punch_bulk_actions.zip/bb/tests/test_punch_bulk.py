"""Activity → Punches: select several error punches and retry or delete them
at once. Bulk actions apply to error punches only; every other state is left
as it is (those keep their own row buttons)."""

from __future__ import annotations

from tests.test_punch_ledger import api, punches  # noqa: F401 — the api fixture


def _ids(api, *states):  # noqa: F811
    rows = punches(api)
    return {s: next(r["id"] for r in rows if r["process_state"] == s) for s in states}


def _states(api):  # noqa: F811
    return {p["id"]: p["process_state"] for p in punches(api)} | \
        {p["id"]: "deleted" for p in punches(api, state="deleted")}


def test_bulk_delete_takes_only_error_punches(api):  # noqa: F811
    ids = _ids(api, "error", "unmapped", "synced", "pending")
    body = api.post("/api/v1/punches/bulk", json={"ids": list(ids.values()), "action": "delete"}).json()
    assert body["changed"] == 1 and body["not_allowed"] == 3, body
    assert "error punches only" in body["message"]
    states = _states(api)
    assert states[ids["error"]] == "deleted"
    assert states[ids["unmapped"]] == "unmapped" and states[ids["synced"]] == "synced"
    assert states[ids["pending"]] == "pending"


def test_bulk_retry_takes_only_error_punches(api):  # noqa: F811
    ids = _ids(api, "error", "unmapped", "synced")
    body = api.post("/api/v1/punches/bulk", json={"ids": list(ids.values()), "action": "retry"}).json()
    assert body["changed"] == 1 and body["not_allowed"] == 2, body
    states = _states(api)
    assert states[ids["error"]] == "pending"
    assert states[ids["unmapped"]] == "unmapped", "unmatched badges keep their own Retry"
    assert states[ids["synced"]] == "synced", "a synced punch is never queued twice"


def test_a_deleted_punch_is_not_restored_in_bulk(api):  # noqa: F811
    ids = _ids(api, "unmapped")
    api.delete(f"/api/v1/punches/{ids['unmapped']}")
    body = api.post("/api/v1/punches/bulk", json={"ids": [ids["unmapped"]], "action": "retry"}).json()
    assert body["changed"] == 0 and body["not_allowed"] == 1


def test_bulk_ignores_other_accounts_punches_and_validates(api):  # noqa: F811
    r = api.post("/api/v1/punches/bulk", json={"ids": ["not-mine"], "action": "delete"})
    assert r.json() == {"changed": 0, "not_allowed": 0, "not_found": 1, "message": "0 punches deleted"}
    assert api.post("/api/v1/punches/bulk", json={"ids": [], "action": "delete"}).status_code == 422
    assert api.post("/api/v1/punches/bulk", json={"ids": ["x"], "action": "nuke"}).status_code == 422
